### Tuts+ Tutorial: Introduction to iOS Testing With UI Automation

#### Instructor: Andy Obusek

Just imagine being able to write scripts that automatically interact with your iOS application and be able to verify the results. With UI Automation you can. UI Automation is a tool provided by Apple to perform a higher level of testing on your iOS application beyond anything achievable with XCTest.

Source files for the Tuts+ tutorial: [Introduction to iOS Testing With UI Automation](http://code.tutsplus.com/tutorials/introduction-to-ios-testing-with-ui-automation--cms-22730)

**Read this tutorial on [Tuts+](https://code.tutsplus.com)**
