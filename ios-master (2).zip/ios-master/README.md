ios
===

# OwnTracks' iPhone App


OwnTracks was __MQTTitude__. Find the history here on github: https://github.com/binarybucks/mqttitude

OwnTracks uses __MQTTClient__, a native Objective-C client framework. https://github.com/ckrey/MQTT-Client-Framework 

### Build your own

OwnTracks iOS uses CocoaPods (https://cocoapods.org) as a package manager.

All packages are included in the repo, but you'll need to install CocoaPods if you want to modify the pods included (`OwnTracks/Podfile`).

As with all CocoaPods projects, you need to open `OwnTracks/OwnTracks.xcworkspace` in XCode, not the `.xcodeproj` file.
