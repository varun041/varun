//
//  Queue+CoreDataProperties.m
//  OwnTracks
//
//  Created by Christoph Krey on 20.02.16.
//  Copyright © 2016-2017 OwnTracks. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Queue+CoreDataProperties.h"

@implementation Queue (CoreDataProperties)

@dynamic timestamp;
@dynamic data;
@dynamic topic;

@end
