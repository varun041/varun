//
//  Location.m
//  OwnTracks
//
//  Created by Christoph Krey on 28.09.15.
//  Copyright © 2015-2017 OwnTracks. All rights reserved.
//

#import "Location.h"
#import "Friend+CoreDataClass.h"

@implementation Location

// Insert code here to add functionality to your managed object subclass

@end
