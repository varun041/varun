//
//  Queue.m
//  OwnTracks
//
//  Created by Christoph Krey on 20.02.16.
//  Copyright © 2016-2017 OwnTracks. All rights reserved.
//

#import "Queue.h"

@implementation Queue

// Insert code here to add functionality to your managed object subclass

@end
