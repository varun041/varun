//
//  Subscription+CoreDataClass.m
//  OwnTracks
//
//  Created by Christoph Krey on 08.12.16.
//  Copyright © 2016-2017 OwnTracks. All rights reserved.
//

#import "Subscription+CoreDataClass.h"
#import "Friend+CoreDataClass.h"
#import "Info+CoreDataClass.h"
@implementation Subscription

@end
