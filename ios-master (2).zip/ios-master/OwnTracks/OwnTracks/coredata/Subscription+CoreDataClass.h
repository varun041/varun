//
//  Subscription+CoreDataClass.h
//  OwnTracks
//
//  Created by Christoph Krey on 08.12.16.
//  Copyright © 2016-2017 OwnTracks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Friend, Info;

NS_ASSUME_NONNULL_BEGIN

@interface Subscription : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Subscription+CoreDataProperties.h"
