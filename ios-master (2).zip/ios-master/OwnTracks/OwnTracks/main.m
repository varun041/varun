//
//  main.m
//  OwnTracks
//
//  Created by Christoph Krey on 03.02.14.
//  Copyright © 2014-2017 OwnTracks. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "OwnTracksAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([OwnTracksAppDelegate class]));
    }
}
