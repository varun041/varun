//
//  TBC.h
//  OwnTracks
//
//  Created by Christoph Krey on 21.06.15.
//  Copyright © 2015-2017 OwnTracks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController
- (void)adjust;
@end
