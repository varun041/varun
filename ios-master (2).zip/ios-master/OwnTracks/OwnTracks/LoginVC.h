//
//  LoginVC.h
//  OwnTracks
//
//  Created by Christoph Krey on 01.07.15.
//  Copyright © 2015-2017 OwnTracks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QRCodeReaderViewController.h"

@interface LoginVC : UIViewController

@end
