//
//  FeaturedContentVC.h
//  OwnTracks
//
//  Created by Christoph Krey on 23.01.16.
//  Copyright © 2016-2017 OwnTracks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeaturedContentVC : UIViewController <UIWebViewDelegate>

@end
