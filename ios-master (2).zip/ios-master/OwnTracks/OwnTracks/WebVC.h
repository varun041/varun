//
//  WebVC.h
//  OwnTracks
//
//  Created by Christoph Krey on 09.09.16.
//  Copyright © 2016-2017 OwnTracks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebVC : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
