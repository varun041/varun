//
//  FriendTVC.h
//  OwnTracks
//
//  Created by Christoph Krey on 29.09.13.
//  Copyright © 2013-2017 Christoph Krey. All rights reserved.
//

#import "Friend+CoreDataClass.h"

@interface FriendsTVC : UITableViewController <NSFetchedResultsControllerDelegate>
@end
