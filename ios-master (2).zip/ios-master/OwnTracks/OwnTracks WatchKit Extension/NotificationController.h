//
//  NotificationController.h
//  OwnTracks WatchKit Extension
//
//  Created by Christoph Krey on 23.04.15.
//  Copyright © 2015-2017 OwnTracks. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface NotificationController : WKUserNotificationInterfaceController

@end
