//
//  SharedFriendsRC.m
//  OwnTracks
//
//  Created by Christoph Krey on 02.04.15.
//  Copyright © 2015-2017 OwnTracks. All rights reserved.
//

#import "SharedFriendsRC.h"

@implementation SharedFriendsRC

@end
